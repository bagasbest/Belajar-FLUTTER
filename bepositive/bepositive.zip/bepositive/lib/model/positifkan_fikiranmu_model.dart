class PositifkanFikiranmuModel {
  String title;
  String description;

  PositifkanFikiranmuModel({
    this.title,
    this.description,
  });
}
