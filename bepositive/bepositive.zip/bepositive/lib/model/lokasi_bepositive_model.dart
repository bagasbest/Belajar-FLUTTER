class LokasiBePositiveModel {
  String name;
  String description;
  String imageAsset;

  LokasiBePositiveModel({
    this.name,
    this.description,
    this.imageAsset,
  });
}
