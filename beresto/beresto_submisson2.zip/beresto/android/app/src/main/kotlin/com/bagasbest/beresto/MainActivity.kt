package com.bagasbest.beresto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
